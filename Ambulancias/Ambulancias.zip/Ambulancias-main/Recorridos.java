public class Recorridos {

     public static void registrarRecorrido() {
        
        System.out.println("==== REGISTRAR NUEVO RECORRIDO ====");
        System.out.print("Escriba el número de la ambulancia (1 a 10): ");
        int numero = Main.teclado.nextInt();
        Main.teclado.nextLine();

        if (numero >= 1 && numero <= 10 && Datos.Ambulancias[numero - 1] != null) {
            System.out.print("¿Cuántos kilómetros desea registrar para esta ambulancia?: ");
            int km = Main.teclado.nextInt();
            Main.teclado.nextLine();

            int posicion = numero - 1;
            int totalActual = Datos.RecorridoAmbulancias[posicion];

            if (totalActual + km <= 400) {
                Datos.RecorridoAmbulancias[posicion] += km;
                System.out.println(" Se registraron " + km + " km. Total ahora: " + Datos.RecorridoAmbulancias[posicion] + " km");
            } else {
                System.out.println(" No se puede registrar. Superaría los 400 km máximos.");
            }
        } else {
            System.out.println("Ambulancia no válida o no registrada.");
        }
    }

    public static void mostrarRecorridos() {
        System.out.println("==== RECORRIDOS POR AMBULANCIA ====");
        for (int i = 0; i < Datos.Ambulancias.length; i++) {
            if (Datos.Ambulancias[i] != null) {
                System.out.println("Ambulancia " + Datos.Ambulancias[i] + ": " + Datos.RecorridoAmbulancias[i] + " km recorridos");
            }
        }
    }
}
