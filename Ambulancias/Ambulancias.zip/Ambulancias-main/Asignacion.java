public class Asignacion {
       public static void asignarConductores() {
        System.out.println("Asignando conductores a ambulancias:");

        for (int i = 0; i < 10; i++) {
            if (Datos.Conductor[i] != null && Datos.Ambulancias[i] != null) {
                System.out.println("Ambulancia " + Datos.Ambulancias[i] + " asignada a conductor: " + Datos.Conductor[i]);
            } else {
                System.out.println("Ambulancia o conductor faltante en posición " + i);
            }
        }

        System.out.println("Asignando conductor a carroza fúnebre:");

        if (Datos.Funeraria[0] != null && Datos.Conductor[9] != null) {
            System.out.println("Funeraria " + Datos.Funeraria[0] + " asignada al conductor: " + Datos.Conductor[9]);
        } else {
            System.out.println("No se puede asignar conductor.");
        }
    }
}

