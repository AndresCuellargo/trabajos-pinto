public class Reporte {
    public static Main Pt = new Main();
    
        public static void generarReporte() {
        System.out.println("REPORTE GENERAL");

        for (int i = 0; i < 10; i++) {
            String ambulancia = Datos.Ambulancias[i];
            String conductor = Datos.Conductor[i];

            if (ambulancia != null && conductor != null) {
                System.out.println("Ambulancia: " + ambulancia);
                System.out.println("Conductor: " + conductor);
                System.out.println("Pacientes recogidos:");

                for (int j = 0; j < 10; j++) {
                    if (Pt.pacientes < Datos.Pacientes.length && Datos.Pacientes[Pt.pacientes] != null) {
                        String paciente = Datos.Pacientes[Pt.pacientes];
                        boolean fallecido = estaMuerto(paciente);
                        System.out.println( paciente + (fallecido ? " FALLECIDO" : ""));
                        Pt.pacientes++;
                    }
                }
            } else {
                System.out.println("Ambulancia o conductor no registrado en posición " + (i + 1));
            }
        }
    }


    private static boolean estaMuerto(String paciente) {
        for (int k = 0; k < Datos.Muertos.length; k++) {
            if (Datos.Muertos[k] != null && Datos.Muertos[k].contains(paciente)) {
                return true;
            }
        }
        return false;
    }
}
