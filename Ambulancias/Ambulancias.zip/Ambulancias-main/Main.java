import java.util.Scanner;

public class Main {
    public static Main Pt = new Main();
    public static Scanner teclado = new Scanner(System.in);
    public static String nombre, apellido, tipoSangre, placa, funeraria;
    public static int edad, telefono;
    int pacientes = 0;

    public static void main(String[] args) {
        System.out.println("Bienvenido al menu");
        System.out.println("1. Conductor");
        System.out.println("2. Pacientes");
        System.out.println("3. Ambulancias");
        System.out.println("4. carro funebre");
        System.out.println("5. asignar conductores");
        System.out.println("6. mostrar y marcar muertos");
        System.out.println("7. recojer los pacientes");
        System.out.println("8. registrary mostrar recorridos");
        System.out.println("9. reporte general");
        System.out.println("10. Salir");

        int opcion = 0;
        do {
            System.out.print("Seleccione una opcion: ");
            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    Conductor.ingresarConductores();
                    Conductor.mostrarConductores();
                    break;
                case 2:
                    Pacientes.ingresarPacientes();
                    Pacientes.mostrarPacientes();
                    break;
                case 3:
                    Ambulancia.ingresarAmbulancias();
                    Ambulancia.mostrarAmbulancias();
                    break;
                case 4:
                    Funebre.ingresarFuneraria();
                    Funebre.mostrarFuneraria();
                    break;
                case 5:
                    Asignacion.asignarConductores();
                    break;
                case 6:
                    Pacientes.marcarPacienteMuerto();
                    Pacientes.mostrarMuertos();
                break;
                case 7:
                    Recojer.recogerPacientes();
                break;
                case 8:
                    Recorridos.registrarRecorrido();
                    Recorridos.mostrarRecorridos();
                break;
                case 9:
                    Reporte.generarReporte();
                break;
                case 10:
                    System.out.println("Salida");
                    break;
                default:
                    System.out.println("Opcion no valida, intente de nuevo.");
            }
        } while (opcion != 10);
    }
}

