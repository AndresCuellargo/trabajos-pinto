public class Datos {

    public static String[] Conductor = new String[10];
    public static String[] Pacientes = new String[100];
    public static String[] Muertos = new String[15];
    public static String[] Funeraria = new String[1];
    public static String[] Ambulancias = new String[10];
    public static int[] RecorridoAmbulancias = new int[10];
}

