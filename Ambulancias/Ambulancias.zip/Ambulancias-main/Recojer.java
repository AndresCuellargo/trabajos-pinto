public class Recojer {

    public static Main Pt = new Main();

     public static void recogerPacientes() {
        System.out.println("Iniciando recojida de pacientes por ambulancia:");

        

        for (int i = 0; i < 10; i++) { // 10 ambulancias
            String ambulancia = Datos.Ambulancias[i];
            if (ambulancia != null) {
                System.out.println("Ambulancia " + ambulancia + " recoge:");

                for (int j = 0; j < 10; j++) { // 10 pacientes por ambulancia
                    if (Pt.pacientes < Datos.Pacientes.length && Datos.Pacientes[Pt.pacientes] != null) {
                        System.out.println("  pacientes " + Datos.Pacientes[Pt.pacientes]);
                        Pt.pacientes++;
                    } else {
                        System.out.println("No hay  pacientes para recoger.");
                        break;
                    }
                }

                System.out.println(); // espacio entre ambulancias
            } else {
                System.out.println("Ambulancia " + (i + 1) + " no registrada.");
            }
        }
    }
}
