
import java.util.Random;
import java.util.Arrays;
import java.util.Scanner;
public class ejercicio{
    public static void main(String[] args){

        Scanner tecvlado = new Scanner(System.in);
        int numeros[][] = new int[3][3];        
        Random Random = new Random();
        int numero;

        System.out.println("el numero ingresado es: ");
        numero = tecvlado.nextInt();
                
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) { 
                numeros[i][j] = Random.nextInt(5)+1;
            }
        }
        
        System.out.println("Estado normal");
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(numeros[i][j] + " ");
            }
            System.out.println();
        }
                
        System.out.println("Estado Inverso: ");
        

        
        int numbersInverse[][] = reverse(numeros);   
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(numbersInverse[i][j] + " ");
            }
            System.out.println();
        }
        
        System.out.println("Estado inverso: " + Arrays.deepToString(numbersInverse));
    }
    public static int[][] reverse(int[][] numbers) {
        int[][] reverseArray = new int[numbers.length][numbers.length];
        
        for (int i = 0; i < numbers[0].length; i++) {
            for (int j = 0; j < numbers.length; j++) {
               reverseArray[numbers.length - 1 - i][numbers[0].length - 1 - j] = numbers[i][j];            
            }
        }
        return reverseArray;
    }
    
}



