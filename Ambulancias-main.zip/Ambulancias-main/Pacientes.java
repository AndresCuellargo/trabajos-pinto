
public class Pacientes {
    public static Main Pt = new Main();

    public static void ingresarPacientes() {
        for (int x = 0; x < 100; x++) {
            System.out.println("Introduce el nombre del paciente " + (x + 1) + ": ");
            Pt.nombre = Main.teclado.nextLine();

            System.out.println("Introduce el apellido del paciente " + (x + 1) + ": ");
            Pt.apellido = Main.teclado.nextLine();

            System.out.println("Introduce el número de teléfono del paciente " + (x + 1) + ": ");
            Pt.telefono = Main.teclado.nextInt();
            Main.teclado.nextLine();

            System.out.println("Introduce tipo de sangre del paciente " + (x + 1) + ": ");
            Pt.tipoSangre = Main.teclado.nextLine();

            System.out.println("Introduce la edad del paciente " + (x + 1) + ": ");
            Pt.edad = Main.teclado.nextInt();
            Main.teclado.nextLine();

            Datos.Pacientes[x] = Pt.nombre + " " + Pt.apellido + " - Tel: " + Pt.telefono + " - Tipo de Sangre: " + Pt.tipoSangre + " - Edad: " + Pt.edad;
        }
    }

    public static void mostrarPacientes() {
        System.out.println(" Lista de pacientes registrados:");
        for (int i = 0; i < Datos.Pacientes.length; i++) {
            if (Datos.Pacientes[i] != null) {
                System.out.println((i + 1) + ". " + Datos.Pacientes[i]);
            }
        }
    }
}


