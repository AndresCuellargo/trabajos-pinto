public class Reporte {
     public static void mostrar() {
        System.out.println("reportes ");

        for (int i = 0; i < Datos.Conductor.length; i++) {
            System.out.printf("Conductor: ", Asignacion.obtenerConductor(i));
            System.out.printf("Ambulancia: ", Asignacion.obtenerAmbulancia(i));
            System.out.printf("Paciente: ", Asignacion.obtenerPaciente(i));
            System.out.printf("Fallecido: ", Asignacion.obtenerFallecido(i));
            System.out.println("--------------------------");
        }

        System.out.println(" vehiculo funebre:");
        System.out.printf("nombre: ", Asignacion.obtenerFuneraria());
    }
}

