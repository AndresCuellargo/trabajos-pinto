public class Ambulancia {
    public static Main Pt = new Main();

    public static void ingresarAmbulancias() {
        for (int x = 0; x < 10; x++) {
            System.out.println("Introduce la placa de la ambulancia " + (x + 1) + ": ");
            Pt.placa = Main.teclado.nextLine();
            Datos.Ambulancias[x] = Pt.placa;
        }
    }

    public static void mostrarAmbulancias() {
        System.out.println(" Lista de ambulancias registradas:");
        for (int i = 0; i < Datos.Ambulancias.length; i++) {
            if (Datos.Ambulancias[i] != null) {
                System.out.println((i + 1) + ". " + Datos.Ambulancias[i]);
            }
        }
    }
}