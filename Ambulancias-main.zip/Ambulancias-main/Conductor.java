
import java.util.Scanner;

public class Conductor {
    public static Main Pt = new Main();
    Scanner teclado = new Scanner(System.in);

    public static void ingresarConductores() {
        for (int x = 0; x < 10; x++) {
            System.out.println("Introduce el nombre del conductor " + (x + 1) + ": ");
            Pt.nombre = Main.teclado.nextLine();

            System.out.println("Introduce el apellido del conductor " + (x + 1) + ": ");
            Pt.apellido = Main.teclado.nextLine();

            System.out.println("Introduce el número de teléfono del conductor " + (x + 1) + ": ");
            Pt.telefono = Main.teclado.nextInt();
            Main.teclado.nextLine();

            Datos.Conductor[x] = Pt.nombre + " " + Pt.apellido + " - Tel: " + Pt.telefono;
        }
    }

    public static void mostrarConductores() {
        System.out.println(" Lista de conductores registrados:");
        for (int i = 0; i < Datos.Conductor.length; i++) {
            if (Datos.Conductor[i] != null) {
                System.out.println((i + 1) + ". " + Datos.Conductor[i]);
            }
        }
    }
}


