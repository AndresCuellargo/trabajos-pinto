import java.util.Scanner;

public class Main {
    public static Main Pt = new Main();
    public static Scanner teclado = new Scanner(System.in);
    public static String nombre, apellido, tipoSangre, placa, funeraria;
    public static int edad, telefono;

    public static void main(String[] args) {
        System.out.println("Bienvenido al menu");
        System.out.println("1. Conductor");
        System.out.println("2. Pacientes");
        System.out.println("3. Muertos");
        System.out.println("4. Funeraria");
        System.out.println("5. Ambulancias");
        System.out.println("6. Salir");

        int opcion = 0;
        do {
            System.out.print("Seleccione una opcion: ");
            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    Conductor.ingresarConductores();
                    Conductor.mostrarConductores();
                    break;
                case 2:
                    Pacientes.ingresarPacientes();
                    Pacientes.mostrarPacientes();
                    break;
                case 3:
                    Ambulancia.ingresarAmbulancias();
                    Ambulancia.mostrarAmbulancias();
                    break;
                case 4:
                    Funebre.ingresarFuneraria();
                    Funebre.mostrarFuneraria();
                    break;
                case 5:
                    Reporte.mostrar();
                    break;
                case 6:
                    System.out.println("Salida");
                    break;
                default:
                    System.out.println("Opcion no valida, intente de nuevo.");
            }
        } while (opcion != 6);
    }
}

