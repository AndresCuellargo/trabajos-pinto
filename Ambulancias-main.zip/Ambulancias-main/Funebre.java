public class Funebre {

    public static Main Pt = new Main();

    public static void ingresarFuneraria() {
        System.out.println("Introduce el nombre de la funeraria: ");
        Pt.funeraria = Main.teclado.nextLine();
        Datos.Funeraria[0] = Pt.funeraria;
    }

    public static void mostrarFuneraria() {
        System.out.println("Nombre de la funeraria registrada: " + Datos.Funeraria[0]);
    }
}

