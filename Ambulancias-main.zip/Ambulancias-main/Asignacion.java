public class Asignacion {


    public static String obtenerDato(String[] arreglo, int index, String porDefecto) {
        return (index < arreglo.length && arreglo[index] != null) ? arreglo[index] : porDefecto;
    }

    public static String obtenerConductor(int index) {
        return obtenerDato(Datos.Conductor, index, "Sin asignar");
    }

    public static String obtenerAmbulancia(int index) {
        return obtenerDato(Datos.Ambulancias, index, "Sin asignar");
    }

    public static String obtenerPaciente(int index) {
        return obtenerDato(Datos.Pacientes, index, "Sin asignar");
    }

    public static String obtenerFallecido(int index) {
        return obtenerDato(Datos.Muertos, index, "Ninguno");
    }

    public static String obtenerFuneraria() {
        return obtenerDato(Datos.Funeraria, 0, "No registrada");
    }
}

